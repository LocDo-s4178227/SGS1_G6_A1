require("dotenv").config();
const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const { db, generateId, generateOrderNumber, saveDb } = require("./data/db");

const app = express();
const PORT = Number(process.env.PORT || 5000);
const passwordResetTokens = new Map();
const activeSessions = new Map();

const UPLOADS_DIR = path.join(__dirname, "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const safeName = file.originalname
      .replace(/\s+/g, "_")
      .replace(/[^a-zA-Z0-9_\.-]/g, "");
    const filename = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}-${safeName}`;
    cb(null, filename);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Only image uploads are allowed"));
    }
    cb(null, true);
  }
});

app.use(cors());
app.use("/uploads", express.static(UPLOADS_DIR));
app.use(express.json());

function sanitizeUser(user) {
  const { password, ...safeUser } = user;
  return safeUser;
}

function isNonEmptyString(value) {
  return typeof value === "string" && value.trim().length > 0;
}

function isValidEmail(value) {
  if (!isNonEmptyString(value)) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

function isStrongPassword(value) {
  if (!isNonEmptyString(value)) return false;
  const password = String(value);
  return (
    password.length >= 8 &&
    /[A-Z]/.test(password) &&
    /[a-z]/.test(password) &&
    /\d/.test(password) &&
    /[^A-Za-z0-9]/.test(password)
  );
}

function normalizeUserTypes(value) {
  const input = Array.isArray(value) ? value : [value || "poster"];
  return input
    .map((entry) => {
      const normalized = String(entry || "").trim().toLowerCase();
      if (!normalized) return null;
      if (normalized === "user" || normalized === "customer") return "poster";
      if (normalized === "pro") return "professional";
      return normalized;
    })
    .filter(Boolean);
}

function buildLoginResponse(user) {
const safeUser = sanitizeUser(user);
const token = `token_${user.id}_${Date.now()}`;
// Remember which user this token belongs to, so any later request
// carrying this token can be resolved back to a real, verified user.
activeSessions.set(token, user.id);
return {
success: true,
user: {
...safeUser,
_id: safeUser.id,
role: safeUser.userType?.[0] || "poster"
},
token
};
}
// Looks up the currently logged-in user from a bearer token.
// Returns null if the token is missing, unknown, or the user no longer exists.
function getUserByToken(token) {
if (!isNonEmptyString(token)) return null;
const userId = activeSessions.get(token.trim());
if (!userId) return null;
return db.users[userId] || null;
}

function getUserIdByResetToken(token) {
  const tokenData = passwordResetTokens.get(token);
  if (!tokenData) return null;
  if (Date.now() > tokenData.expiresAt) {
    passwordResetTokens.delete(token);
    return null;
  }
  return tokenData.userId;
}

function getCart(sessionId) {
  if (!db.carts[sessionId]) {
    db.carts[sessionId] = {
      sessionId,
      items: []
    };
  }
  return db.carts[sessionId];
}

app.get("/api/health", (_req, res) => {
  res.json({ success: true, status: "ok" });
});

app.post("/api/auth/logout", (req, res) => {
const authHeader = req.headers["authorization"] || "";
const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : authHeader.trim();
if (token) activeSessions.delete(token);
return res.json({ success: true });
});

app.post("/api/auth/login", (req, res) => {
  const { email, username, password } = req.body || {};
  const loginIdentifier = String(email || username || "").trim().toLowerCase();

  if (!isNonEmptyString(loginIdentifier) || !isNonEmptyString(password)) {
    return res.status(400).json({ success: false, message: "Email/username and password are required" });
  }

  const user = Object.values(db.users).find(
    (u) => u.email.toLowerCase() === loginIdentifier || String(u.username || "").toLowerCase() === loginIdentifier
  );

  if (!user || user.password !== password) {
    return res.status(401).json({ success: false, message: "Invalid email or password" });
  }

  if (!user.active) {
    return res.status(403).json({ success: false, message: "Account is deactivated" });
  }

  return res.json(buildLoginResponse(user));
});

app.post("/api/auth/register", (req, res) => {
  const {
    username,
    firstName,
    lastName,
    email,
    password,
    role,
    userType
  } = req.body || {};

  if (!isValidEmail(email)) {
    return res.status(400).json({ success: false, message: "A valid email is required" });
  }

  if (!isStrongPassword(password)) {
    return res.status(400).json({
      success: false,
      message: "Password must be at least 8 chars and include uppercase, lowercase, number, and special character"
    });
  }

  const submittedUsername = String(username || "").trim();
  if (!submittedUsername) {
    return res.status(400).json({ success: false, message: "Username is required" });
  }

  if (submittedUsername.length < 3 || submittedUsername.length > 20) {
    return res.status(400).json({ success: false, message: "Username must be 3-20 characters" });
  }

  const existing = Object.values(db.users).find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(409).json({ success: false, message: "Email already registered" });
  }

  const usernameTaken = Object.values(db.users).some(
    (u) => String(u.username || "").toLowerCase() === submittedUsername.toLowerCase()
  );
  if (usernameTaken) {
    return res.status(409).json({ success: false, message: "Username already taken" });
  }

  const normalizedTypes = normalizeUserTypes(userType || role);
  if (!normalizedTypes.length) {
    return res.status(400).json({ success: false, message: "At least one user type is required" });
  }

  const id = generateId("user");
  const newUser = {
    id,
    firstName: String(firstName || submittedUsername).trim(),
    lastName: String(lastName || "User").trim(),
    username: submittedUsername,
    email: String(email).trim().toLowerCase(),
    password,
    phone: "",
    location: "",
    description: "",
    profilePicture: "",
    userType: normalizedTypes,
    preferences: {
      emailNotifications: true,
      messageNotifications: true,
      newRequestNotifications: true
    },
    active: true
  };

  db.users[id] = newUser;
  saveDb(db);

  return res.status(201).json(buildLoginResponse(newUser));
});

app.post("/api/auth/forgot-password", (req, res) => {
  const { email } = req.body || {};

  if (!isValidEmail(email)) {
    return res.status(400).json({ success: false, message: "A valid email is required" });
  }

  const user = Object.values(db.users).find((u) => u.email.toLowerCase() === String(email).trim().toLowerCase());
  if (!user) {
    return res.status(404).json({ success: false, message: "No account found for that email" });
  }

  if (!user.active) {
    return res.status(403).json({ success: false, message: "Account is deactivated" });
  }

  const resetToken = `reset_${generateId("token")}`;
  passwordResetTokens.set(resetToken, {
    userId: user.id,
    expiresAt: Date.now() + 15 * 60 * 1000
  });

  return res.json({ success: true, resetToken });
});

app.post("/api/auth/reset-password", (req, res) => {
  const { token, newPassword } = req.body || {};
  const userId = getUserIdByResetToken(token);

  if (!userId) {
    return res.status(400).json({ success: false, message: "Invalid or expired reset token" });
  }

  if (!isStrongPassword(newPassword)) {
    return res.status(400).json({
      success: false,
      message: "Password must be at least 8 chars and include uppercase, lowercase, number, and special character"
    });
  }

  const user = db.users[userId];
  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  user.password = String(newPassword);
  passwordResetTokens.delete(token);
  saveDb(db);
  return res.json({ success: true });
});

app.get("/api/auth/user/:id", (req, res) => {
  const user = db.users[req.params.id];
  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }
  return res.json(sanitizeUser(user));
});

app.put("/api/auth/user/:id", (req, res) => {
  const user = db.users[req.params.id];
  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  const allowed = [
    "firstName",
    "lastName",
    "email",
    "phone",
    "location",
    "description",
    "profilePicture",
    "preferences"
  ];

  const updatedEmail = req.body?.email;
  if (typeof updatedEmail !== "undefined") {
    if (!isValidEmail(updatedEmail)) {
      return res.status(400).json({ success: false, message: "Email format is invalid" });
    }

    const emailTaken = Object.values(db.users).some(
      (candidate) => candidate.id !== user.id && candidate.email.toLowerCase() === String(updatedEmail).trim().toLowerCase()
    );
    if (emailTaken) {
      return res.status(409).json({ success: false, message: "Email already in use" });
    }
  }

  if (typeof req.body?.firstName !== "undefined" && !isNonEmptyString(req.body.firstName)) {
    return res.status(400).json({ success: false, message: "First name cannot be empty" });
  }

  if (typeof req.body?.lastName !== "undefined" && !isNonEmptyString(req.body.lastName)) {
    return res.status(400).json({ success: false, message: "Last name cannot be empty" });
  }

  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(req.body || {}, key)) {
      if (key === "email") {
        user[key] = String(req.body[key]).trim().toLowerCase();
      } else {
        user[key] = req.body[key];
      }
    }
  }

  saveDb(db);

  return res.json({ success: true, user: sanitizeUser(user) });
});

app.post("/api/auth/change-password", (req, res) => {
  const { userId, currentPassword, newPassword } = req.body || {};
  const user = db.users[userId];

  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  if (user.password !== currentPassword) {
    return res.status(401).json({ success: false, message: "Current password is incorrect" });
  }

  if (!isStrongPassword(newPassword)) {
    return res.status(400).json({
      success: false,
      message: "New password must be at least 8 chars and include uppercase, lowercase, number, and special character"
    });
  }

  if (newPassword === currentPassword) {
    return res.status(400).json({ success: false, message: "New password must be different from current password" });
  }

  user.password = newPassword;
  saveDb(db);
  return res.json({ success: true });
});

app.put("/api/auth/user/:id/deactivate", (req, res) => {
  const user = db.users[req.params.id];
  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  user.active = false;
  saveDb(db);
  return res.json({ success: true });
});

app.delete("/api/auth/user/:id", (req, res) => {
  const user = db.users[req.params.id];
  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  const { password } = req.body || {};
  if (user.password !== password) {
    return res.status(401).json({ success: false, message: "Password is incorrect" });
  }

  delete db.users[req.params.id];
  saveDb(db);
  return res.json({ success: true });
});

app.get("/api/cart/:sessionId", (req, res) => {
  const cart = getCart(req.params.sessionId);
  const subtotal = cart.items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  res.json({
    sessionId: cart.sessionId,
    items: cart.items,
    subtotal
  });
});

app.post("/api/cart/:sessionId/items", (req, res) => {
  const cart = getCart(req.params.sessionId);
  const { productId, quantity, textDetails, unitPrice } = req.body || {};

  if (!isNonEmptyString(productId)) {
    return res.status(400).json({ success: false, message: "Product ID is required" });
  }

  const parsedQuantity = Number(quantity);
  const parsedUnitPrice = Number(unitPrice);
  if (!Number.isInteger(parsedQuantity) || parsedQuantity <= 0) {
    return res.status(400).json({ success: false, message: "Quantity must be a positive integer" });
  }

  if (!Number.isFinite(parsedUnitPrice) || parsedUnitPrice <= 0) {
    return res.status(400).json({ success: false, message: "Unit price must be a positive number" });
  }

  if (typeof textDetails !== "undefined" && (textDetails === null || typeof textDetails !== "object" || Array.isArray(textDetails))) {
    return res.status(400).json({ success: false, message: "Text details must be an object" });
  }

  const item = {
    id: generateId("cartitem"),
    productId,
    quantity: parsedQuantity,
    textDetails: textDetails || {},
    unitPrice: parsedUnitPrice
  };

  cart.items.push(item);
  saveDb(db);
  return res.status(201).json({ success: true, item, items: cart.items });
});

app.put("/api/cart/:sessionId/items/:itemId", (req, res) => {
  const cart = getCart(req.params.sessionId);
  const item = cart.items.find((i) => i.id === req.params.itemId);

  if (!item) {
    return res.status(404).json({ success: false, message: "Cart item not found" });
  }

  const { quantity, textDetails } = req.body || {};
  if (typeof quantity !== "undefined") {
    const parsedQuantity = Number(quantity);
    if (!Number.isInteger(parsedQuantity) || parsedQuantity <= 0) {
      return res.status(400).json({ success: false, message: "Quantity must be a positive integer" });
    }
    item.quantity = parsedQuantity;
  }
  if (typeof textDetails !== "undefined") {
    if (textDetails === null || typeof textDetails !== "object" || Array.isArray(textDetails)) {
      return res.status(400).json({ success: false, message: "Text details must be an object" });
    }
    item.textDetails = textDetails;
  }

  saveDb(db);

  return res.json({ success: true, item, items: cart.items });
});

app.delete("/api/cart/:sessionId/items/:itemId", (req, res) => {
  const cart = getCart(req.params.sessionId);
  const initialLength = cart.items.length;
  cart.items = cart.items.filter((i) => i.id !== req.params.itemId);

  if (cart.items.length === initialLength) {
    return res.status(404).json({ success: false, message: "Cart item not found" });
  }

  saveDb(db);

  return res.json({ success: true, items: cart.items });
});

app.post("/api/orders/checkout/:sessionId", (req, res) => {
  const { sessionId } = req.params;
  const cart = getCart(sessionId);

  if (!cart.items.length) {
    return res.status(400).json({ success: false, message: "Cart is empty" });
  }

  const subtotal = cart.items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const shippingCost = Number(req.body?.shippingCost || 0);
  const taxRate = Number(req.body?.taxRate || 0.1);

  if (!Number.isFinite(shippingCost) || shippingCost < 0) {
    return res.status(400).json({ success: false, message: "Shipping cost is invalid" });
  }

  if (!Number.isFinite(taxRate) || taxRate < 0 || taxRate > 1) {
    return res.status(400).json({ success: false, message: "Tax rate must be between 0 and 1" });
  }

  const payment = req.body?.payment || {};
  const delivery = req.body?.delivery || {};
  const requiredDeliveryFields = ["fullName", "phone", "addressLine1", "city", "postalCode"];
  for (const field of requiredDeliveryFields) {
    if (!isNonEmptyString(delivery[field])) {
      return res.status(400).json({ success: false, message: `Delivery field '${field}' is required` });
    }
  }

  if (!isNonEmptyString(payment.cardholderName) || !isNonEmptyString(payment.cardLast4)) {
    return res.status(400).json({ success: false, message: "Payment details are incomplete" });
  }

  const taxAmount = (subtotal + shippingCost) * taxRate;
  const total = subtotal + shippingCost + taxAmount;

  const order = {
    id: generateId("order"),
    orderNumber: generateOrderNumber(),
    sessionId,
    items: cart.items,
    payment,
    delivery,
    subtotal,
    shippingCost,
    taxAmount,
    total,
    createdAt: new Date().toISOString()
  };

  db.orders.push(order);
  cart.items = [];
  saveDb(db);

  return res.status(201).json({ success: true, order });
});

// GET /api/marketplace - Build request/proposal listings from threads + their replies
app.get("/api/marketplace", (req, res) => {
  const listings = (db.threads || []).map((thread) => {
    const replies = (db.replies || []).filter((r) => r.threadId === thread.id);
    const offers = replies.filter((r) => typeof r.price === "number");
    const latestOffer = offers.length
      ? offers.reduce((latest, r) => (new Date(r.posted_at) > new Date(latest.posted_at) ? r : latest))
      : null;

    return {
      id: thread.id,
      title: thread.title,
      author: thread.author,
      description: thread.content,
      image: thread.image || "",
      status: thread.status || "Open",
      postedAt: thread.posted_at,
      offerCount: replies.length,
      price: latestOffer ? Number(latestOffer.price) : null
    };
  });

  res.json({ success: true, listings });
});

// ==========================================
// --- DISCUSSION FORUM API ROUTES ---
// ==========================================

// 1. GET /api/threads - Fetch all threads (Supports Search by title/content, Filter by status, & Sorting)
app.get("/api/threads", (req, res) => {
  let results = [...(db.threads || [])];
  const { title, content, status, sort } = req.query;

  // Search by Title
  if (isNonEmptyString(title)) {
    results = results.filter((t) =>
      t.title.toLowerCase().includes(title.trim().toLowerCase())
    );
  }

  // Search by Content
  if (isNonEmptyString(content)) {
    results = results.filter((t) =>
      t.content.toLowerCase().includes(content.trim().toLowerCase())
    );
  }

  // Filter by Status (Open, Negotiating, Resolved, Closed, etc.)
  if (isNonEmptyString(status)) {
    results = results.filter(
      (t) => t.status.toLowerCase() === status.trim().toLowerCase()
    );
  }

  // Sorting logic
  if (sort === "oldest") {
    results.sort((a, b) => new Date(a.posted_at) - new Date(b.posted_at));
  } else if (sort === "title_asc") {
    results.sort((a, b) => a.title.localeCompare(b.title));
  } else if (sort === "title_desc") {
    results.sort((a, b) => b.title.localeCompare(a.title));
  } else {
    // Default: Newest first
    results.sort((a, b) => new Date(b.posted_at) - new Date(a.posted_at));
  }

  res.json({ success: true, count: results.length, threads: results });
});

// 2. GET /api/threads/:id - Fetch single thread details along with its replies
app.get("/api/threads/:id", (req, res) => {
  const thread = (db.threads || []).find((t) => t.id === req.params.id);
  if (!thread) {
    return res.status(404).json({ success: false, message: "Thread not found" });
  }

  const threadReplies = (db.replies || []).filter(
    (r) => r.threadId === req.params.id
  );
  
  // Sort replies chronologically (oldest to newest for smooth reading)
  threadReplies.sort((a, b) => new Date(a.posted_at) - new Date(b.posted_at));

  res.json({
    success: true,
    thread: {
      ...thread,
      replies: threadReplies
    }
  });
});

// Temporary login middleware for the Discussion Forum.
// Later, replace this with the real User Account authentication (shared module).
// For now the client sends the currently logged-in user's username in the
// "x-username" header (see apiRequest() in Discussion_forum.js), so that
// ownership checks below can compare it against thread.author / reply.author.
// Real login middleware for the Discussion Forum, wired to the shared
// User Account module's login/register sessions (see activeSessions above).
// The client sends "Authorization: Bearer <token>" (see apiRequest() in
// Discussion_forum.js). The server looks the token up itself and resolves
// req.user from its own database - it never trusts a username the client
// claims to be, so a request can't be spoofed into editing/deleting someone
// else's post just by sending a different header value.
function requireLogin(req, res, next) {
const authHeader = req.headers["authorization"] || "";
const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : authHeader.trim();
const user = getUserByToken(token);
if (!user) {
return res.status(401).json({ success: false, message: "You must be logged in to do this." });
}
if (!user.active) {
return res.status(403).json({ success: false, message: "Your account is deactivated." });
}
req.user = { userId: user.id, username: user.username };
next();
}

// Applied to both /api/threads and /api/replies so req.user (and therefore
// ownership checks) is available on every discussion-forum route.
app.use(["/api/threads", "/api/replies"], requireLogin);

// Helper: checks whether the currently logged-in user (req.user) owns the
// given resource (a thread or a reply, both of which have an "author" field).
function isOwner(req, resource) {
    if (!resource || !req.user) return false;
    return String(resource.author || "").trim().toLowerCase() ===
        String(req.user.username || "").trim().toLowerCase();
}

// 3. POST /api/threads - Create a new thread
app.post("/api/threads", upload.single("image"), (req, res) => {
  const { title, content, status } = req.body || {};

  // Author is always the currently authenticated user (from requireLogin),
  // never a value the client sends in the body - otherwise anyone could
  // post a thread pretending to be someone else.
  const author = req.user && req.user.username;

  if (!isNonEmptyString(title) || title.trim().length < 5) {
    return res.status(400).json({ success: false, message: "Title must be at least 5 characters" });
  }
  if (!isNonEmptyString(content) || content.trim().length < 10) {
    return res.status(400).json({ success: false, message: "Content must be at least 10 characters" });
  }

  let imageUrl = "";
  if (req.file) {
    imageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  } else if (req.body.image) {
    imageUrl = req.body.image;
  }

  const id = generateId("thread");
  const newThread = {
    id,
    author,
    title: title.trim(),
    content: content.trim(),
    posted_at: new Date().toISOString(),
    image: imageUrl || "",
    status: status || "Open",
    replyCount: 0
  };

  if (!db.threads) db.threads = [];
  db.threads.push(newThread);
  saveDb(db);

  return res.status(201).json({ success: true, thread: newThread });
});

// 4. PUT /api/threads/:id - Update an existing thread
app.put("/api/threads/:id", upload.single("image"), (req, res) => {
  const thread = (db.threads || []).find((t) => t.id === req.params.id);
  if (!thread) {
    return res.status(404).json({ success: false, message: "Thread not found" });
  }

  // Ownership check: only the original author may edit their own thread.
  if (!isOwner(req, thread)) {
    return res.status(403).json({ success: false, message: "You can only edit your own posts" });
  }

  const { title, content, status } = req.body || {};

  if (typeof title !== "undefined") {
    if (!isNonEmptyString(title) || title.trim().length < 5) {
      return res.status(400).json({ success: false, message: "Title must be at least 5 characters" });
    }
    thread.title = title.trim();
  }

  if (typeof content !== "undefined") {
    if (!isNonEmptyString(content) || content.trim().length < 10) {
      return res.status(400).json({ success: false, message: "Content must be at least 10 characters" });
    }
    thread.content = content.trim();
  }

  if (req.file) {
    thread.image = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  } else if (typeof req.body.image !== "undefined") {
    thread.image = req.body.image || "";
  }
  if (typeof status !== "undefined") thread.status = status;

  saveDb(db);
  return res.json({ success: true, thread });
});

// 5. DELETE /api/threads/:id - Delete a thread and cascade delete all its associated replies
app.delete("/api/threads/:id", (req, res) => {
  const thread = (db.threads || []).find((t) => t.id === req.params.id);
  if (!thread) {
    return res.status(404).json({ success: false, message: "Thread not found" });
  }

  // Ownership check: only the original author may delete their own thread.
  if (!isOwner(req, thread)) {
    return res.status(403).json({ success: false, message: "You can only delete your own posts" });
  }

  db.threads = (db.threads || []).filter((t) => t.id !== req.params.id);

  // Cascade delete related replies
  db.replies = (db.replies || []).filter((r) => r.threadId !== req.params.id);

  saveDb(db);
  return res.json({ success: true, message: "Thread and all associated replies deleted successfully" });
});

// 6. POST /api/threads/:id/replies - Post a reply / quote offer under a thread
app.post("/api/threads/:id/replies", upload.single("image"), (req, res) => {
  const thread = (db.threads || []).find((t) => t.id === req.params.id);
  if (!thread) {
    return res.status(404).json({ success: false, message: "Thread not found" });
  }

  const { title, content, price } = req.body || {};
  // Author is always the currently authenticated user (from requireLogin),
  // never a value the client sends in the body.
  const author = req.user.username;
  if (!isNonEmptyString(title)) {
    return res.status(400).json({ success: false, message: "Reply title is required" });
  }
  if (!isNonEmptyString(content)) {
    return res.status(400).json({ success: false, message: "Reply content is required" });
  }

  const parsedPrice = price !== undefined ? Number(price) : 0;
  if (Number.isNaN(parsedPrice) || parsedPrice < 0) {
    return res.status(400).json({ success: false, message: "Price must be a valid non-negative number" });
  }

  let imageUrl = "";
  if (req.file) {
    imageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  } else if (req.body.image) {
    imageUrl = req.body.image;
  }

  const newReply = {
    id: generateId("reply"),
    threadId: req.params.id,
    author: author.trim(),
    title: title.trim(),
    content: content.trim(),
    price: parsedPrice,
    posted_at: new Date().toISOString(),
    image: imageUrl || ""
  };

  if (!db.replies) db.replies = [];
  db.replies.push(newReply);
  
  // Increment thread reply count
  thread.replyCount = (thread.replyCount || 0) + 1;
  if (parsedPrice > 0 && (thread.status || "Open").toLowerCase() === "open") {
  thread.status = "Negotiating";
}
  saveDb(db);
  return res.status(201).json({ success: true, reply: newReply });
});

// 7. PUT /api/replies/:replyId - Update a reply / quote offer
app.put("/api/replies/:replyId", upload.single("image"), (req, res) => {
  const reply = (db.replies || []).find((r) => r.id === req.params.replyId);
  if (!reply) {
    return res.status(404).json({ success: false, message: "Reply not found" });
  }

  // Ownership check: only the original author may edit their own reply.
  if (!isOwner(req, reply)) {
    return res.status(403).json({ success: false, message: "You can only edit your own replies" });
  }

  const { title, content, price } = req.body || {};

  if (typeof title !== "undefined") {
    if (!isNonEmptyString(title)) {
      return res.status(400).json({ success: false, message: "Reply title cannot be empty" });
    }
    reply.title = title.trim();
  }

  if (typeof content !== "undefined") {
    if (!isNonEmptyString(content)) {
      return res.status(400).json({ success: false, message: "Reply content cannot be empty" });
    }
    reply.content = content.trim();
  }

  if (typeof price !== "undefined") {
    const parsedPrice = Number(price);
    if (Number.isNaN(parsedPrice) || parsedPrice < 0) {
      return res.status(400).json({ success: false, message: "Price must be a valid non-negative number" });
    }
    reply.price = parsedPrice;
  }

  if (req.file) {
    reply.image = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  } else if (typeof req.body.image !== "undefined") {
    reply.image = req.body.image || "";
  }

  saveDb(db);
  return res.json({ success: true, reply });
});

// 8. DELETE /api/replies/:replyId - Delete a single reply
app.delete("/api/replies/:replyId", (req, res) => {
  const reply = (db.replies || []).find((r) => r.id === req.params.replyId);
  if (!reply) {
    return res.status(404).json({ success: false, message: "Reply not found" });
  }

  // Ownership check: only the original author may delete their own reply.
  if (!isOwner(req, reply)) {
    return res.status(403).json({ success: false, message: "You can only delete your own replies" });
  }

  // Decrement thread reply count
  const thread = (db.threads || []).find((t) => t.id === reply.threadId);
  if (thread && thread.replyCount > 0) {
    thread.replyCount -= 1;
  }

  db.replies = db.replies.filter((r) => r.id !== req.params.replyId);

  saveDb(db);
  return res.json({ success: true, message: "Reply deleted successfully" });
});

app.use((_req, res) => {
  res.status(404).json({ success: false, message: "Route not found" });
});

app.listen(PORT, () => {
  console.log(`Backend API running on http://localhost:${PORT}`);
});
